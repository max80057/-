
import com.model.TestBean;
import com.model.UserBean;

public interface testMapper {
	
	public String select1(String userName);//最普通範例
	
	public UserBean select2(TestBean bean);//傳入、回傳bean
	
	public List<HashMap<String,String>> select3(String userName,String userId);//普通傳入也可以這樣寫，多個參數也可
	
	public String select4(@Param("userName") String str1,@Param("userId")String str2);//@Param()內為傳入mybatis內的參數名稱，若需要指定可以這樣做
	
	public String select5(List list);//陣列內容
}