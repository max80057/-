package com.aia.tw.staff.portal.main;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

//import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class test {
	
//	private static Logger logger = Logger.getLogger(test.class);
	
	public static void main(String[] args) {
		FileOutputStream fo = null;
		XSSFWorkbook xwb = null;
		try {
			
			//建立物件
			xwb = new XSSFWorkbook();
			
			//建立sheet
			XSSFSheet sheet = xwb.createSheet("第一個sheet");
			
			//取消第0列自動欄位寬
			sheet.autoSizeColumn(0, false);
			//設定第0列欄位寬
			int widthPoints = sheet.getColumnWidth(0);
			sheet.setColumnWidth(0, (int) (widthPoints * 1.3f));
			
			//建立文字物件
			Font contentFont = xwb.createFont();
			//字體
			contentFont.setFontName("標楷體");
			//字體大小
			contentFont.setFontHeightInPoints((short) 14);
			//是否粗體
			contentFont.setBold(true);
			//粗體設定
			contentFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
			//字體顏色
			contentFont.setColor(HSSFColor.RED.index);
			//下底線
			contentFont.setUnderline((byte) 1);
			
			
			//欄位設定物件
			CellStyle contentCenterStyle = xwb.createCellStyle();
			//水平對齊
			contentCenterStyle.setAlignment(CellStyle.ALIGN_CENTER);
			//垂直對齊
			contentCenterStyle.setVerticalAlignment(CellStyle.ALIGN_CENTER);
			//下邊框
			contentCenterStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			contentCenterStyle.setBottomBorderColor(HSSFColor.BLACK.index);
			//左邊框
			contentCenterStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			contentCenterStyle.setLeftBorderColor(HSSFColor.BLACK.index);
			//又邊框
			contentCenterStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			contentCenterStyle.setRightBorderColor(HSSFColor.BLACK.index);
			//上邊框
			contentCenterStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
			contentCenterStyle.setTopBorderColor(HSSFColor.BLACK.index);
			//自動換行
			contentCenterStyle.setWrapText(false);
			
			
			//資料設定
			int rowNum = 0;
			//建立第0行
			Row row = sheet.createRow(rowNum);
			//建立第0個欄位，合併欄位
			Cell cell = row.createCell(0);
			cell.setCellValue("合併的第一行");
			cell.setCellStyle(contentCenterStyle);
			
			//合併欄位，參數分別為，合併開始行，結束行，開始列，結束列
			sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 1));
			
			//建立第1行、第0個欄位
			rowNum++;
			row = sheet.createRow(rowNum);
			cell = row.createCell(0);
			cell.setCellValue("123");
			cell.setCellStyle(contentCenterStyle);
			
			cell = row.createCell(1);
			cell.setCellValue("987");
			cell.setCellStyle(contentCenterStyle);

			
			//寫入檔案
			File tmpFile = new File("d:\\test1.xlsx");
			fo = new FileOutputStream(tmpFile);
			xwb.write(fo);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//釋放資源
			try {
				xwb.close();
				fo.flush();
				fo.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
}
